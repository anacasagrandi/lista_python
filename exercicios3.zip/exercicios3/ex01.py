# Times de São Paulo
sp_times = ["Corinthians", "Palmeiras", "Santos", "São Paulo"]
print("")
# Times do Rio de Janeiro
rj_times = ["Flamengo", "Fluminense", "Botafogo", "Vasco da Gama"]

print("Times de São Paulo:")
for time in sp_times:
    print(time)

print("\nTimes do Rio de Janeiro:")
for time in rj_times:
    print(time)