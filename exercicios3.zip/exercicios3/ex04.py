# Solicita os dois números ao usuário
num1 = float(input("Digite o primeiro número: "))
num2 = float(input("Digite o segundo número: "))

# Faz as 3 somas
soma1 = num1 + num2
soma2 = num1 + num2 + 10
soma3 = num1 + num2 + 20

# Exibe os resultados das 3 somas
print("Soma 1:", soma1)
print("Soma 2:", soma2)
print("Soma 3:", soma3)

# Calcula o totalizador
totalizador = soma1 + soma2 + soma3

# Exibe o totalizador
print("Totalizador:", totalizador)